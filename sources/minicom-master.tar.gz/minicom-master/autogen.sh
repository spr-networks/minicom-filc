#! /bin/sh

set -x

if ! command -v autopoint > /dev/null; then
  echo "No 'autopoint' installed. Please install."
  exit 1
fi

if ! command -v pkg-config > /dev/null; then
  echo "No 'pkg-config' installed. Please install."
  exit 1
fi

autoreconf -fi
